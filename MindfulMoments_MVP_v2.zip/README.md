
# MindfulMoments MVP

## Deployment
1. Push to GitHub
2. Import to Vercel
3. Add `OPENAI_API_KEY` and optional `DISABLE_AI` environment variables
4. Deploy

## Features
- AI-generated micro-activity plans
- Local cache per activity
- PWA installable and offline fallback
